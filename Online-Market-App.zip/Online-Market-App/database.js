const { MongoClient, ServerApiVersion } = require("mongodb");
const uri =
  "mongodb+srv://snehap:aBtA5LRkz6ayCGvL@marketplace.qi8jefd.mongodb.net/?retryWrites=true&w=majority";

// Create a MongoClient with a MongoClientOptions object to set the Stable API version
const client = new MongoClient(uri, {
  serverApi: {
    version: ServerApiVersion.v1,
    strict: true,
    deprecationErrors: true,
  },
});

let conn;
try {
  // Connect the client to the server	(optional starting in v4.7)
  conn = client.connect();
  // Send a ping to confirm a successful connection
  // await client.db("marketplace").command({ ping: 1 });

  console.log("Pinged your deployment. You successfully connected to MongoDB!");
} catch (e) {
  // Ensures that the client will close when you finish/error
  // client.close();
  console.error(e);
}

// run().catch(console.dir);
let db = client.db("marketplace");

module.exports = db;
// export default db;
// try {
//   conn = await client.connect();
// } catch (e) {
//   console.error(e);
// }
// let db = conn.db("sample_training");

// export default db;
