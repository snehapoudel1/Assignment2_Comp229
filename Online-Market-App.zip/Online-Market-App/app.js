const express = require("express");
const mongoose = require("mongoose");
const app = express();
app.use(express.json());

// const db = require("./database");
const port = 8080;

mongoose.connect(
  "mongodb+srv://snehap:aBtA5LRkz6ayCGvL@marketplace.qi8jefd.mongodb.net/marketplace?retryWrites=true&w=majority",
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  }
);

app.get("/", (req, res) => {
  var message = { message: "Welcome to DressStore application." };
  res.json(message);
});

const productRoutes = require("./routes");

app.use("/api", productRoutes);

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
