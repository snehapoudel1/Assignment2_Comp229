const express = require("express");
const router = express.Router();

const Product = require("../models/Product");

router.get("/products", async (req, res) => {
  try {
    const products = await Product.find();
    res.json(products);
  } catch (e) {
    res.status(500).json({ message: e });
  }
});

router.get("/products/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const product = await Product.findById(id);
    if (!product) {
      res.status(404).json({ message: "Product with this ID not found" });
    }
    res.json(product);
  } catch (e) {
    res.status(500).json({ message: e });
  }
});

router.post("/products", async (req, res) => {
  try {
    const { name, description, price, quantity, category } = req.body;
    const newProduct = new Product({
      name,
      description,
      price,
      quantity,
      category,
    });
    const savedProduct = await newProduct.save();
    res.json(savedProduct);
  } catch (e) {
    res.status(500).json({ message: e });
  }
});

router.put("/products/:id", async (req, res) => {
  try {
    const { name, description, price, quantity, category } = req.body;
    const { id } = req.params;
    const updatedProduct = await Product.findByIdAndUpdate(id, {
      name,
      description,
      price,
      quantity,
      category,
    });
    if (!updatedProduct) {
      res.status(404).json({ message: "Product with this ID not found" });
    }
    res.json(updatedProduct);
  } catch (e) {
    res.status(500).json({ message: e });
  }
});

router.delete("/products/:id", async (req, res) => {
  try {
    const { id } = req.params;
    const deletedProduct = await Product.findByIdAndRemove(id);
    if (!deletedProduct) {
      return res
        .status(404)
        .json({ message: "Product with this ID not found" });
    }
    res.json(deletedProduct);
  } catch (error) {
    res.status(500).json({ message: e });
  }
});

router.delete("/products/", async (req, res) => {
  try {
    await Product.deleteMany({});
    res.json({ message: "All products deleted" });
  } catch (error) {
    res.status(500).json({ message: e });
  }
});

router.get("/product", async (req, res) => {
  try {
    const { name } = req.query;
    console.log(name);
    const products = await Product.find();
    const filtered = [];
    for (const product of products) {
      if (product.name.toLowerCase().startsWith(name.toLowerCase())) {
        filtered.push(product);
      }
    }
    res.json(filtered);
  } catch (e) {
    res.status(500).json({ message: e });
  }
});

module.exports = router;
